zcat 2019-Nov.csv.zip | head -n 1000 > 2019-Nov-sample.csv
